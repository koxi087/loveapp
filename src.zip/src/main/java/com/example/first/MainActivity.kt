package com.example.first

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.first.ui.theme.FirstTheme

// 1. Definiáljuk a füleket (képernyőket) egy lezárt osztályban
sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Ertesitesek : Screen("notifications", "Értesítések", Icons.Default.Notifications)
    object Naptar : Screen("calendar", "Naptár", Icons.Default.DateRange)
    object Kuponok : Screen("coupons", "Kuponok", Icons.Default.ShoppingCart)
    object Beallitasok : Screen("settings", "Beállítások", Icons.Default.Settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FirstTheme {
                MainContent()
            }
        }
    }
}

@Composable
fun MainContent() {
    // Egyedi színek kódjai
    val hatterSzin = Color(0xFFDEB587)
    val kijeloltSzin = Color(0xFFE5AA70)

    // Aktuálisan kiválasztott fül állapota
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Ertesitesek) }

    val items = listOf(
        Screen.Ertesitesek,
        Screen.Naptar,
        Screen.Kuponok,
        Screen.Beallitasok
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Egybefüggő alsó menü (Facebook stílus)
            NavigationBar(
                containerColor = hatterSzin,
                tonalElevation = 0.dp
            ) {
                items.forEach { screen ->
                    val selected = currentScreen == screen

                    NavigationBarItem(
                        selected = selected,
                        onClick = { currentScreen = screen },
                        label = {
                            Text(
                                text = screen.title,
                                color = Color.Black,
                                fontSize = 11.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title,
                                tint = Color.Black
                            )
                        },
                        // Kerekített sarkú kijelölés háttérszíne aktív állapotban
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = kijeloltSzin
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        // Fő tartalom konténer a kért háttérszínnel
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(hatterSzin),
            contentAlignment = Alignment.Center
        ) {
            // Dinamikus tartalomváltás a fülek alapján
            when (currentScreen) {
                Screen.Ertesitesek -> PageContent(title = "Értesítések")
                Screen.Naptar -> PageContent(title = "Naptár")
                Screen.Kuponok -> PageContent(title = "Kuponok")
                Screen.Beallitasok -> PageContent(title = "Beállítások")
            }
        }
    }
}

@Composable
fun PageContent(title: String) {
    Text(
        text = title,
        fontSize = 30.sp,
        fontWeight = FontWeight.Bold,
        color = Color.Black // Fekete szöveg a jó olvashatóságért a sárgás háttéren
    )
}

// Az Android Studio jobb oldali előnézeti ablakához (Preview)
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    FirstTheme {
        MainContent()
    }
}
